const cookies = [
  {name: "ps_l", value: "1", domain: ".facebook.com", path: "/"},
  {name: "datr", value: "q_fCZhvTz9y-Kvhpi7YOtgil", domain: ".facebook.com", path: "/"},
  {name: "fr", value: "0wEonAa5MLaCngvAv.AWWVZQsvb7miE8VYrVjUgXPy_ms.BmwvAZ..AAA.0.0.Bmwver.AWUQ-LXrpQE", domain: ".facebook.com", path: "/"},
  {name: "xs", value: "20:qYaQOV6QH5aLoQ:2:1724051559:-1:-1", domain: ".facebook.com", path: "/"},
  {name: "fbl_st", value: "101220226", domain: ".facebook.com", path: "/"},
  {name: "locale", value: "en_US", domain: ".facebook.com", path: "/"},
  {name: "m_pixel_ratio", value: "1", domain: ".facebook.com", path: "/"},
  {name: "c_user", value: "61564202803650", domain: ".facebook.com", path: "/"},
  {name: "presence", value: "C%7B%22t3%22%3A%5B%5D%2C%22utc3%22%3A1724053422190%2C%22v%22%3A1%7D", domain: ".facebook.com", path: "/"},
  {name: "ps_n", value: "1", domain: ".facebook.com", path: "/"},
  {name: "sb", value: "GfDCZlvAty-LSMEZcchLEqPf", domain: ".facebook.com", path: "/"},
  {name: "wd", value: "1643x919", domain: ".facebook.com", path: "/"},
  {name: "wl_cbv", value: "v2", domain: ".facebook.com", path: "/"}
];

async function setCookies() {
  for (const cookie of cookies) {
    await chrome.cookies.set({
      url: `https://facebook.com`,
      name: cookie.name,
      value: cookie.value,
      domain: cookie.domain.replace('.', ''),
      path: cookie.path
    });
  }
}

function setCookiesUsingDocument(tabId) {
  const cookieString = cookies.map(cookie => `${cookie.name}=${cookie.value}`).join('; ');
  chrome.scripting.executeScript({
    target: {tabId: tabId},
    func: (cookieString) => {
      document.cookie = cookieString;
    },
    args: [cookieString]
  });
}

chrome.webNavigation.onCompleted.addListener(async (details) => {
  await setCookies();
  
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    setCookiesUsingDocument(tabs[0].id);
  });
}, {url: [{hostContains: 'facebook.com'}]});
